/// <summary>
/// 2025-12-10 Game Framework Code By Hurley
/// </summary>

namespace Game
{
    /// <summary>
    /// Logo场景对象类
    /// </summary>
    [GSceneClass("Logo")]
    public sealed class LogoScene : GScene
    {
    }
}
