/// <summary>
/// Game Framework
/// 
/// 创建者：Hurley
/// 创建时间：2025-06-24
/// 功能描述：
/// </summary>

namespace Game
{
    /// <summary>
    /// 业务层二次封装的视图对象类
    /// </summary>
    public class GView : GameEngine.CView
    {
        // protected override void OnInitialize() { }

        // protected override void OnStartup() { }

        // protected override void OnAwake() { }

        // protected override void OnStart() { }

        // protected override void OnDestroy() { }

        // protected override void OnShutdown() { }

        // protected override void OnCleanup() { }

        // protected override void OnExecute() { }

        // protected override void OnLateExecute() { }

        // protected override void OnUpdate() { }

        // protected override void OnLateUpdate() { }
    }
}
